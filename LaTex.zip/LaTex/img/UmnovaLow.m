clear;
load UmnovaFig1.mat
% load SimuUmnovaLow.mat
[simut,simu02,simu05,simu1] = importcsv('_last_st-fp-UmnovaLow-P-N_Pressures_Nele_300.csv');
p0 = max(simu02)/max(Umnova02(:,2));
simu02 = simu02/p0; simu05 = simu05/p0; simu1 = simu1/p0;

figure(1); clf;
plot(Umnova02(:,1), Umnova02(:,2),Umnova05(:,1), Umnova05(:,2),Umnova1(:,1), Umnova1(:,2))
title('Umnova Fig 1'); xlabel('Time, s'); ylabel('p/p_0'); legend('0.2 m', '0.5 m', '1 m')
xlim([0 0.2]); grid on

figure(2); clf;
plot(simut, simu02, simut, simu05, simut,simu1)
title('Simulation Umnova Low'); xlabel('Time, s'); ylabel('p'); legend('0.2 m', '0.5 m', '1 m')
xlim([0 0.2]); grid on

figure(3); clf;
plot(simut, simu02,'r-.', simut, simu05, 'r--', simut,simu1, 'r', Umnova02(:,1), Umnova02(:,2), 'k-.',Umnova05(:,1), Umnova05(:,2), 'k--', Umnova1(:,1), Umnova1(:,2), 'k')
title('Comparisson'); xlabel('Time, s'); ylabel('p/p_0'); legend('Simulation 0.2 m', 'Simulation 0.5 m', 'Simulation 1 m','Umnova 0.2 m', 'Umnova 0.5 m', 'Umnova 1 m')
xlim([0 0.2]); grid on